import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

// Your Google Calendar API test code goes here
let accessToken = "ya29.a0ATi6K2veE6ONjRDPfmfly-IKVOruvRaQmqBuAIvyvrl4-AxAEMznI6GCZ0wpmCzXNpQCIxOzH-SVHSRTdkxkkies8IsRNPB9B2b4f9ImAObrtwbplSlCVWx6XFsIdSrX7He9Ms1m555v5k6wYblu0OJ0Opf0hRwYav4jOFaRGRx4SQ8ObQiOEyD2nh9FgGRzMUiZgs4aCgYKAe8SARESFQHGX2MiEDQbtO7JmhtV2D6maSWixg0206"

let url = URL(string: "https://www.googleapis.com/calendar/v3/calendars/primary/events")!
var request = URLRequest(url: url)
request.addValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")

struct CalendarEvent: Codable {
    struct DateTimeInfo: Codable {
        let dateTime: String?
        let date: String?
    }
    let id: String
    let summary: String?
    let start: DateTimeInfo
    let end: DateTimeInfo
}

struct EventsResponse: Codable {
    let items: [CalendarEvent]
}

URLSession.shared.dataTask(with: request) { data, response, error in
    if let error = error {
        print("❌ Error:", error)
        return
    }
    
    guard let httpResponse = response as? HTTPURLResponse else {
        print("❌ Invalid response")
        return
    }
    
    guard (200...299).contains(httpResponse.statusCode) else {
        print("❌ HTTP Error:", httpResponse.statusCode)
        if let data = data, let msg = String(data: data, encoding: .utf8) {
            print(msg)
        }
        return
    }
    
    guard let data = data else {
        print("❌ No data returned")
        return
    }
    
    do {
        let decoded = try JSONDecoder().decode(EventsResponse.self, from: data)
        print("✅ Successfully fetched \(decoded.items.count) events:")
        for event in decoded.items {
            print("📅 \(event.summary ?? "(No Title)")")
            print("   Start:", event.start.dateTime ?? event.start.date ?? "Unknown")
            print("   End:", event.end.dateTime ?? event.end.date ?? "Unknown")
            print("----------")
        }
    } catch {
        print("❌ Failed to decode JSON:", error)
        if let json = String(data: data, encoding: .utf8) {
            print("Raw JSON:\n", json)
        }
    }
}.resume()
